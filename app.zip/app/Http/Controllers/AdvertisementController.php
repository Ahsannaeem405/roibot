<?php

namespace App\Http\Controllers;

use App\Models\Advertisement;
use App\Models\AdvertisementAds;
use App\Models\AdvertisementDetail;
use Carbon\Carbon;
use Illuminate\Http\Request;

class AdvertisementController extends Controller
{
    public function PostAdd(Request $request)
    {
      //  dd($request->input());
        $i=0;
        $img1=null;
        //dd($request->input());

        $advertisement = new Advertisement();
        $advertisement->goal = $request->goal;
        $advertisement->user_id = \Auth::user()->id;

        $advertisement->age = $request->age;
        $advertisement->gender = $request->gender;
        $advertisement->per_day = $request->perday_budget;

        $advertisement->type = $request->advert_type;
        $advertisement->save();



        foreach ($request->body as $body) {
            $advertisementDetail = new AdvertisementDetail();
            $advertisementDetail->data = $body;
            $advertisementDetail->advertisements_id = $advertisement->id;
            $advertisementDetail->type = 'body';
            $advertisementDetail->save();



        }


        for ( $j=0;  $j< count($request->btn);  $j++) {
            $advertisementDetail = new AdvertisementDetail();
            $advertisementDetail->data = $request->btn[$j];
            $advertisementDetail->url = $request->url[$j];
            $advertisementDetail->advertisements_id = $advertisement->id;
            $advertisementDetail->type = 'button';
            $advertisementDetail->save();

        }


        foreach ($request->image as $image) {

            $advertisementDetail = new AdvertisementDetail();


            if($i==0)
            {
                $img1=$image;
                $i=1;
            }

            $advertisementDetail->data = $image;
            $advertisementDetail->advertisements_id = $advertisement->id;
            $advertisementDetail->type = 'image';
            $advertisementDetail->save();

        }

        foreach ($request->heading as $heading) {
            $advertisementDetail = new AdvertisementDetail();
            $advertisementDetail->data = $heading;
            $advertisementDetail->advertisements_id = $advertisement->id;
            $advertisementDetail->type = 'heading';
            $advertisementDetail->save();

            $advertisementAdds=new AdvertisementAds();
            $advertisementAdds->advertisements_id=$advertisement->id;
            $advertisementAdds->heading=$heading;
            $advertisementAdds->body=$request->body[0];
            $advertisementAdds->button=$request->btn[0];
            $advertisementAdds->url=$request->url[0];
            $advertisementAdds->image=$img1;
            $advertisementAdds->start_date=Carbon::now();
            $advertisementAdds->end_date=Carbon::now()->addDays(3);

            $advertisementAdds->save();


        }




        return redirect('manage_view')->with('success','Add created successfully');
    }


    public function conpainDelete($id)
    {
        $compain=Advertisement::find($id)->delete();
        return redirect('manage_view')->with('success','Compain deleted successfully');
    }
}
