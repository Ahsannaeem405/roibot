<?php

namespace App\Http\Controllers;

use App\Models\Advertisement;
use App\Models\AdvertisementAds;
use App\Models\mediaGallary;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{

    public function profile()
    {
        $user=\Auth::user();
        return view('profile',compact('user'));
    }

    public function profileUpdate(Request $request)
    {

        $user = User::find(\Auth::user()->id);

        if ($request->old_password && $request->password) {

            $request->validate([

                'password' => ['required', 'confirmed'],


            ]);


            if (Hash::check($request->old_password, $user->password)) {
                $user->fill([
                    'password' => Hash::make($request->password)
                ])->save();

               // return back()->with('success', 'Password Update successfully');

            } else {

                return back()->with('error', 'Password does not match');

            }



        }

        $user->name=$request->name;
        if ($request->hasfile('profile')) {
            $file = $request->file('profile');
            $extension = $file->getClientOriginalExtension(); // getting image extension
            $filename = time() . '.' . $extension;
            $file->move('images/profile/', $filename);
            $user->profile=$filename;
        }


        $user->update();
        return back()->with('success', 'Profile Update successfully');
    }
    function create_ad($id)
    {
        $advert = $id;
        $gallary=mediaGallary::where('user_id',\Auth::user()->id)->OrderBY('id','DESC')->get();
        return view('create_add', compact('advert','gallary'));
    }

    public function ManageAdd()
    {
        $compain = Advertisement::where('user_id', \Auth::user()->id)->orderBy('id', 'DESC')->get();
        return view('manage_view', compact('compain'));
    }

    public function main()
    {
        $compain = Advertisement::where('user_id', \Auth::user()->id)->orderBy('id', 'DESC')->get();
        return view('index', compact('compain'));
    }

    public function mangeDetail($id)
    {
        $compain = Advertisement::where('id', $id)->orderBy('id', 'DESC')->get();
        return view('manage_detail', compact('compain'));
    }

    public function insightDetail($id,$add)
    {

        $compain = Advertisement::where('id', $id)->orderBy('id', 'DESC')->first();
        $add=AdvertisementAds::find($add);
        return view('insights_detail', compact('compain','add'));
    }

    public function insightView()
    {
        $compain = Advertisement::where('user_id', \Auth::user()->id)->orderBy('id', 'DESC')->get();
        return view('insight_view', compact('compain'));
    }

    public function uploadImgae(Request $request)
    {
        if ($request->hasFile('file')) {
            $gallary = new mediaGallary();
            $gallary->user_id = \Auth::user()->id;

            $file = $request->file;
            $extension = $file->getClientOriginalExtension(); // getting image extension
            $filename = $file->getClientOriginalName();
            $file->move('images/gallary/', $filename);


            $gallary->image = $filename;
            $gallary->save();
        }
    }

    public function getImages()
    {
        $gallary=mediaGallary::where('user_id',\Auth::user()->id)->OrderBY('id','DESC')->get();

       return view('getImage',compact('gallary'));
    }

    public function mediaGallery()
    {
        $gallary=mediaGallary::where('user_id',\Auth::user()->id)->OrderBY('id','DESC')->get();
        return view('mediaGallery',compact('gallary'));
    }

    public function galleryDelete(Request $request)
    {
        if($request->check)
        {
            mediaGallary::whereIn('id',$request->check)->delete();
            return back()->with('success','Record deleted successfully');
        }
        else{
            return back()->with('error','Please select image to delete');
        }

    }
}
