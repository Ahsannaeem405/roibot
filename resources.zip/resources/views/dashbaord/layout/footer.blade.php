<footer class="footer">
    <div class="container-fluid">
        <div class="row text-muted">
            <div class="col-12 text-center">
                <p class="mb-0">

                    <a class="text-muted" href="{{url('/admin/index')}}" >

                        <strong>{{'admin'}}</strong>

                    </a> &copy;
                </p>
            </div>

        </div>
    </div>
</footer>
